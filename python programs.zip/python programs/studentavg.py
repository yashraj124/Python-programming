class student:

    school ='telusko'

    def __init__(self,m1,m2,m3):
        self.m1=m1
        self.m2=m2
        self.m3=m3

    def avg(self):
        return(self.m1+self.m2+self.m3)/3
    @classmethod
    def info(cls):
        return cls.school

    @staticmethod
    def info1():
        print("this is student 1")
    

s1 = student(56,67,87)
s2 = student(77,89,76)

print(s1.avg())
print(s2.avg())

print(student.info())
student.info1()
