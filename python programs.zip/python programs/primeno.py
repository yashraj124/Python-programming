def prime(num):
    for i in range(2,num):
        if num%i==0:
            print("Entered number is not prime")

        else:
            print("Entered number is prime")
    
result=prime(14)
print(result)
