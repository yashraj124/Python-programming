from numpy import *

arr = linspace(0,15,8)


print(arr)
