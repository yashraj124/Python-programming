from numpy import *

m1=matrix('1 2 3;5 6 7;5 6 9')
m2=matrix('1 2 3;5 2 6;4 7 8')

m3=m1 * m2;

print(m3)
