f= open('fileexample.py','r')
print(f.readline(), end='')


f1= open('ab','w')
f1.write('something')
