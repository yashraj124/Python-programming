
x = 10

for arr in range(0,x,2):
    print(arr,end =" ")
