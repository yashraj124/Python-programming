num1=int(input("Enter 1st Number"))
num2=int(input("Enter 2nd Number"))
num3=int(input("Enter 3rd Number"))
num4=int(input("Enter 4th Number"))

if(num1>num2 and num1>num3 and num1>num4):
    print(num1,"Number Is Greater")

elif(num2>num1 and num2>num3 and num2>num4):
    print(num2,"Number Is Greater")

elif(num3>num1 and num3>num2 and num3>num4):
    print(num3,"Number Is Greater")

else:
    print(num4,"Number Is Greater")
