class student:
    def __init__(self,name,rollno):
        self.name=name
        self.rollno=rollno

s1=student("vaishnavi",3240)
s2=student("abcd",1234)

print(s1.name,s1.rollno)
