my name navin
python course
telusko youtube
hp laptop
