def update(x):
    x=5
    print(x)

a=10
update(a)
print(a,id(a))
