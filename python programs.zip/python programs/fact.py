def fact(n):

    f=1

    for i in range(1,n+1):
        f=f*i

    return f



#result=fact(6)

print(fact(6))
