Char=str(input("Enter A Character"))
if(Char=='a' or Char=='e' or Char=='i' or Char=='o' or Char=='u'):
    print("Character Is Vowel")

else:
    print("Character Is Consonant")
