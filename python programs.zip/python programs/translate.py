s1="abcdei"
s2="123456"
s3="python sample string abcdei"
table=str.maketrans(s1,s2)
result=s3.translate(table)
print(result)
