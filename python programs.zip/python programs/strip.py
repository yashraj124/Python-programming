s="*****This is my first program*****"
s1=s.strip("*")
print(s1)
