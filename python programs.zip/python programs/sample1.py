x = 'vishal {}'
y = 2000

print(x.format(y))
