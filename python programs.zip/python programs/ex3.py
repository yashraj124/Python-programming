class print_i_c:
    def printing(self,i,c):
        print("integer is",int(i))

    def printing(self,c,i):
        print("character is",(c))
p=print_i_c()
p.printing(3,'a')
p.printing('a',3)

        
