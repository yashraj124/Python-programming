s = [2,3,4,5]

rev = s[::-1]

print(rev)
