def sum ( *b):

    c = 0
    for i in b:
        c = c+i

    print(c)

sum(5,6,74,34)
