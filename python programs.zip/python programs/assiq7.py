x = int(input('enter x'))

for i in range (0,x,1):
    c = bin(i, end=' ')

    print(c)
