Percentage=float(input("Enter Your Percentage"))
if(Percentage>=90):
    print(Percentage,"You Got A+ Grade")
elif(Percentage>=80 and Percentage<=90):
    print(Percentage,"You Got A Grade")
elif(Percentage>=70 and Percentage<=80):
    print(Percentage,"You Got B+ Grade")
elif(Percentage>=60 and Percentage<=70):
    print(Percentage,"You Got B Grade")
elif(Percentage>=50 and Percentage<=60):
    print(Percentage,"You Got C Grade")
else:
    print("You Are Fail")

   
