def greet():
    print("Good Morning")
    print("Hello")

def add_sub_mul_div(a,b):
    c=a+b
    d=a-b
    e=a*b
    f=a//b
    #print(c)
    return c,d,e,f
greet()
result,result1,result2,result4 = add_sub_mul_div(5,5)
print(result,result1,result2,result4)
