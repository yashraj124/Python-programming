height=int(input("Enter value for height :"))
width=int(input("Enter value for width :"))
areaofrectangle=height*width
print("Area of Rectangle :",areaofrectangle)
