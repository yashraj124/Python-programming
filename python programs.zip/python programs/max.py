list=[5,10,22,40,12]
for i in list:
    print(i)
    max(list)
print(max)
