f = lambda n : n%2==0

nums=(1,2,3,4,5,6,78)

evens=tuple(filter(f,nums))
print(evens)
