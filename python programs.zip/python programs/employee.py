class employee():
    name=""
    department=""
    salary=0
    def acceptEmployee(self):
        self.name=input("enter employee name")
        self.department=input("enter employee department")
        self.salary=int(input("enter employee salary"))

    def displayEmployee(self):
        print("employee name is",self.name)
        print("employee department is",self.department)
        print("employee salary is",self.salary)


e=employee()
e.acceptEmployee()
e.displayEmployee()
