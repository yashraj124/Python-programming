a=4
b=0

try:
    print("resource open")
    print(a/b)

except Exception as e:
    print("hey,you cannot divide a number by zero")

finally:
    print("resource closed")
    
    
    
