sub1=(int(input("Enter marks of sub1")))
sub2=(int(input("Enter marks of sub2")))
sub3=(int(input("Enter marks of sub3")))
sub4=(int(input("Enter marks of sub4")))
sub5=(int(input("Enter marks of sub5")))
totalmarks=sub1+sub2+sub3+sub4+sub5
print(totalmarks)
percentage=totalmarks/5
print(percentage)

if percentage>=75:
    print("destignation")

elif percentage>=60:
    print("first class")

elif percentage>=40:
    print("second class")

elif percentage<40:
    print("fail")
