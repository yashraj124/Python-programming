num1=18
num2=8180954462
print("my age is {} and my phone number is {}".format(num1,num2))
