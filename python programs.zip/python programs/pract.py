def myfunc(text,num):
    while num > 0:
        print(text)
    num = num - 1
myfunc('Hello', 4)
