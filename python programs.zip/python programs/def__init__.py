class computer:

    def __init__(self):
        self.name="vaishnavi"
        self.age=18

    #def update(self):
   #     self.age=18

    def compare(self,other):
        if self.age==other.age:
            return True
        else:
            return False

c1=computer()


c1.age=18
c2=computer()
c2.age=18
if c1.compare(c2):
    print("they are same")
else:
    print("they are different")

print(c1.name)
print(c2.name)
