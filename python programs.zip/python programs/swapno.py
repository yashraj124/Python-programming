a=int(input("Enter value of a:"))
b=int(input("Enter value of b:"))
temp=0
temp=a
a=b
b=temp

print("value of a :",a)
print("value of b :",b)
