name=['hello','world']
name1=['hello','world']
name2=name1

print(name1 is not name)
