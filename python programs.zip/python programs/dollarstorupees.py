dollars=float(input("Enter dollars"))
rupees=dollars*64
print(rupees,"rupees")
