


for i in range(1,11):
    for i<10:
        add = c +i
        i+=1
    
    

print(n)
