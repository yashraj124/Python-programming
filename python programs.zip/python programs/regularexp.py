#import re
"""s="26-11-2002"
r=re.compile("^([0-9]{2})-([0-9]{2})-([0-9]{4})$")

m=re.search(r,s)
if m:
    print(m.group(2))
else:
    print("pattern not found")"""


l = ['abc','abcd','abcde','zzzzzz']
l2 = [len(value) for value in l]
print(l2)


l2=[(value1,value2) for value1 in range(1,5) for value2 in range(50,52)]
print(l2)
