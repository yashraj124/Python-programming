x=4
for i in range(x):
    x+=1
    print(x)
