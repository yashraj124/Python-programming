a = [1,2,3,4,300]

#b = bytes(a)
for i in a:
    print(i)
