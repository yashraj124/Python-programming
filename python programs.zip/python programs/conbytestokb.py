x = int(input('enter no. of bytes'))

a = x/1000            #kilobytes
b = ((x/1000)/1000)   #megabytes
c = ((x/1000)/10**6)  #gegabytes
d = ((x/1000)/10**9)  #terabytes

print('the converted no. of kilobites = {}'.format(a))
print('the converted no. of megabites = {}'.format(b))
print('the converted no. of gegabites = {}'.format(c))
print('the converted no. of terabites = {}'.format(d))
