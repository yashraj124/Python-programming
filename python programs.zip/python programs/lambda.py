f=lambda a,b:a/b

print(f(9,2))
