def update(l):
    
    print(l)
    l[1]=25
    l.append(5)
     
    print('x',l)
    print(id(l))

l=[10,20,30,40]
print(id(l)) 
update(l) 
