num=int(input("Enter a Number"))
if(num%2==0):
    print(num,"Is Even Number")

else:
    print(num,"Is Odd Number")
