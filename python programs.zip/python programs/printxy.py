x = int(input("enter x"))
y = int(input("enter y"))
z = x+y
print("sum of two numbers:",z)
