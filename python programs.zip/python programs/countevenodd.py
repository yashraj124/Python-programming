
def count(int):

    even=0
    odd=0

    for i in lst:
        if  i%2==0:
            even+=1
        else:
            odd+=1

    return even,odd

lst=[10,12,23,24,43,56,62,51,26,78]

even,odd=count(lst)

print("even:{} and odd:{}".format(even,odd))
