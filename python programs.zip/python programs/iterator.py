
s = [2,3,4,5]

it = iter(s)

print(next(it))
print(next(it))
