s = 'python is my langauge'

print(s[7:10])
