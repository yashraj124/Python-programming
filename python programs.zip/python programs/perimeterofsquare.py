s=int(input("enter a side length of a square"))
p=4*s
print("perimeter of square is",p)
