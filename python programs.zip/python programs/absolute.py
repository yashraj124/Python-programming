num=int(input("Enter a number"))
print(abs(num))
