from array import *

arr=array('i',[])
n=int(input("enter the length of array"))

for i in range(0,n):
    x=int(input("enter next value"))
    arr.append(x)
print(arr)    


val = int(input('enter the value for search'))

print(arr.index(val))
