from array import *

v= array('u',['a','e','i'])

for e in v:
    print(e,end="")
