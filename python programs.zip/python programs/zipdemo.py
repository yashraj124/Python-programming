names=("vaishnavi","vishal")
comps=("dell","ms")

zipped=zip(names,comps)
#print(zipped)


for (a,b)in zipped:
    print(a,b)
