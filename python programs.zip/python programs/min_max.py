list=[10,29,30,45,43]

print(max(list))
print(min(list))
