from numpy import *

arr=([1,2,3,4,5,6])
arr1=([7,8,9,10,11,20])

print(concatenate([arr,arr1]))
