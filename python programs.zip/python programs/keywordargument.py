def person(name,**data):

    print(name)
    for i,j in data.items():
        print(i,j)

person("vaishnavi",age =18,city= "solapur",mob= 8180954462)

