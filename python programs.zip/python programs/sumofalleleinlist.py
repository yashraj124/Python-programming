sum=0
list=[10,20,30,40]

for i in list:
    print(i)
    sum=sum+i
    i+=1
print(sum)
