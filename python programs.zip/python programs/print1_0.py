rows = int(input("Enter the number of rows: "))  
  
# It is used to print space  
k = 1 * rows - 1
# Outer loop in reverse order  
for i in range(rows,-1, -1):  
    # Inner loop will print the number of space.  
    for j in range(k,-1, -1):  
        print(end=" ")    
    # This inner loop will print the number o stars  
    for j in range(1,i + 1):
        k=k+1
        print("1 0", end=" ")  
    print("")  
