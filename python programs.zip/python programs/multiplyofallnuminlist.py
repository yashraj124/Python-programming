mul=1
list=[1,2,3,4]
for i in list:
    mul=mul*i
    i+=1
print("multiplication of all number is",mul)
