from calc import *

a=5
b=10

c=div(a,b)

print(c)
