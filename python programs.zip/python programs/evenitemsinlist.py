list=[2,3,4,23,32,50]
print("even items in list")
print(list[0:5:2])
