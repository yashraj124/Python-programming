Age=int(input("Enter Your Age"))
if(Age>=18):
    print("You Are Illegible For Voting!!!!")
else:
    print("You Are Not Illegible For Voting!!!!")
    
