a=int(input("Enter a number"))
b=int(input("Enter a number"))
c=int(input("Enter a number"))

if a>b and a>c:
    print("A is largest number")
    

elif b>a and b>c:
    print("B is largest number")
    

elif c>a and c>b:
    print("c is largest number")
